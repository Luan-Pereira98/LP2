﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExecutar_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[5, 3];
            double[] medias = new double[5];
            double MediaGeral = 0;

            for (int i = 0; i < notas.GetLength(0); i++)
            {
                double media = 0;

                notas[i, 0] = i;

                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    notas[i, j] = double.Parse(Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1}: ",
                        $"Entrada Aluno {i + 1}"));

                    if (notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Nota Inválida");
                        j--;
                    }
                    else 
                        media += notas[i, j];
                }

                medias[i] = media / 3;

                MediaGeral += media / 3;


            }

            for (int i = 0; i < medias.GetLength(0); i++)
                lstbxAlunoseNotas.Items.Add($"Aluno {i + 1}: Nota Professor 1= {notas[i,0]} Nota Professor 2= {notas[i, 1]} Nota Professor 3= {notas[i, 2]} Média= {medias[i].ToString("N2")} \n");

            lstbxAlunoseNotas.Items.Add($"Média Geral Alunos= {MediaGeral / 5}");
        }
    }
}
