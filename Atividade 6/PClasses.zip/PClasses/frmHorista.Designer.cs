﻿namespace PClasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInstHorista = new System.Windows.Forms.Button();
            this.gbxHome = new System.Windows.Forms.GroupBox();
            this.rbtnNao = new System.Windows.Forms.RadioButton();
            this.rbtnSim = new System.Windows.Forms.RadioButton();
            this.lblEntradaEmpresa = new System.Windows.Forms.Label();
            this.lblSalarioHora = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.txtEntradaEmpresa = new System.Windows.Forms.TextBox();
            this.txtSalarioHora = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lblQtdeHoras = new System.Windows.Forms.Label();
            this.txtQtdeHoras = new System.Windows.Forms.TextBox();
            this.lblQtdeFalta = new System.Windows.Forms.Label();
            this.txtQtdeFalta = new System.Windows.Forms.TextBox();
            this.gbxHome.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnInstHorista
            // 
            this.btnInstHorista.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInstHorista.Location = new System.Drawing.Point(269, 294);
            this.btnInstHorista.Name = "btnInstHorista";
            this.btnInstHorista.Size = new System.Drawing.Size(262, 118);
            this.btnInstHorista.TabIndex = 9;
            this.btnInstHorista.Text = "Instanciar Horista";
            this.btnInstHorista.UseVisualStyleBackColor = true;
            this.btnInstHorista.Click += new System.EventHandler(this.BtnInstHorista_Click);
            // 
            // gbxHome
            // 
            this.gbxHome.Controls.Add(this.rbtnNao);
            this.gbxHome.Controls.Add(this.rbtnSim);
            this.gbxHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxHome.Location = new System.Drawing.Point(466, 137);
            this.gbxHome.Name = "gbxHome";
            this.gbxHome.Size = new System.Drawing.Size(294, 109);
            this.gbxHome.TabIndex = 19;
            this.gbxHome.TabStop = false;
            this.gbxHome.Text = "Trabalha em Home Office";
            // 
            // rbtnNao
            // 
            this.rbtnNao.AutoSize = true;
            this.rbtnNao.Location = new System.Drawing.Point(6, 71);
            this.rbtnNao.Name = "rbtnNao";
            this.rbtnNao.Size = new System.Drawing.Size(69, 29);
            this.rbtnNao.TabIndex = 8;
            this.rbtnNao.TabStop = true;
            this.rbtnNao.Text = "Não";
            this.rbtnNao.UseVisualStyleBackColor = true;
            // 
            // rbtnSim
            // 
            this.rbtnSim.AutoSize = true;
            this.rbtnSim.Location = new System.Drawing.Point(6, 48);
            this.rbtnSim.Name = "rbtnSim";
            this.rbtnSim.Size = new System.Drawing.Size(66, 29);
            this.rbtnSim.TabIndex = 7;
            this.rbtnSim.TabStop = true;
            this.rbtnSim.Text = "Sim";
            this.rbtnSim.UseVisualStyleBackColor = true;
            // 
            // lblEntradaEmpresa
            // 
            this.lblEntradaEmpresa.AutoSize = true;
            this.lblEntradaEmpresa.Font = new System.Drawing.Font("Bodoni MT Condensed", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEntradaEmpresa.Location = new System.Drawing.Point(41, 182);
            this.lblEntradaEmpresa.Name = "lblEntradaEmpresa";
            this.lblEntradaEmpresa.Size = new System.Drawing.Size(201, 24);
            this.lblEntradaEmpresa.TabIndex = 18;
            this.lblEntradaEmpresa.Text = "Data de Entrada na Empresa";
            // 
            // lblSalarioHora
            // 
            this.lblSalarioHora.AutoSize = true;
            this.lblSalarioHora.Font = new System.Drawing.Font("Bodoni MT Condensed", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioHora.Location = new System.Drawing.Point(41, 103);
            this.lblSalarioHora.Name = "lblSalarioHora";
            this.lblSalarioHora.Size = new System.Drawing.Size(127, 24);
            this.lblSalarioHora.TabIndex = 17;
            this.lblSalarioHora.Text = "Salário Por Hora";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Bodoni MT Condensed", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(41, 64);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(49, 24);
            this.lblNome.TabIndex = 16;
            this.lblNome.Text = "Nome";
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Font = new System.Drawing.Font("Bodoni MT Condensed", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatricula.Location = new System.Drawing.Point(41, 28);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(76, 24);
            this.lblMatricula.TabIndex = 15;
            this.lblMatricula.Text = "Matrícula";
            // 
            // txtEntradaEmpresa
            // 
            this.txtEntradaEmpresa.Location = new System.Drawing.Point(256, 185);
            this.txtEntradaEmpresa.Name = "txtEntradaEmpresa";
            this.txtEntradaEmpresa.Size = new System.Drawing.Size(136, 20);
            this.txtEntradaEmpresa.TabIndex = 5;
            // 
            // txtSalarioHora
            // 
            this.txtSalarioHora.Location = new System.Drawing.Point(256, 106);
            this.txtSalarioHora.Name = "txtSalarioHora";
            this.txtSalarioHora.Size = new System.Drawing.Size(136, 20);
            this.txtSalarioHora.TabIndex = 3;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(256, 67);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(316, 20);
            this.txtNome.TabIndex = 2;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(256, 31);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(136, 20);
            this.txtMatricula.TabIndex = 1;
            // 
            // lblQtdeHoras
            // 
            this.lblQtdeHoras.AutoSize = true;
            this.lblQtdeHoras.Font = new System.Drawing.Font("Bodoni MT Condensed", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdeHoras.Location = new System.Drawing.Point(41, 142);
            this.lblQtdeHoras.Name = "lblQtdeHoras";
            this.lblQtdeHoras.Size = new System.Drawing.Size(130, 24);
            this.lblQtdeHoras.TabIndex = 23;
            this.lblQtdeHoras.Text = "Número de Horas";
            // 
            // txtQtdeHoras
            // 
            this.txtQtdeHoras.Location = new System.Drawing.Point(256, 145);
            this.txtQtdeHoras.Name = "txtQtdeHoras";
            this.txtQtdeHoras.Size = new System.Drawing.Size(136, 20);
            this.txtQtdeHoras.TabIndex = 4;
            // 
            // lblQtdeFalta
            // 
            this.lblQtdeFalta.AutoSize = true;
            this.lblQtdeFalta.Font = new System.Drawing.Font("Bodoni MT Condensed", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQtdeFalta.Location = new System.Drawing.Point(41, 223);
            this.lblQtdeFalta.Name = "lblQtdeFalta";
            this.lblQtdeFalta.Size = new System.Drawing.Size(102, 24);
            this.lblQtdeFalta.TabIndex = 25;
            this.lblQtdeFalta.Text = "Dias de Faltas";
            // 
            // txtQtdeFalta
            // 
            this.txtQtdeFalta.Location = new System.Drawing.Point(256, 226);
            this.txtQtdeFalta.Name = "txtQtdeFalta";
            this.txtQtdeFalta.Size = new System.Drawing.Size(136, 20);
            this.txtQtdeFalta.TabIndex = 6;
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblQtdeFalta);
            this.Controls.Add(this.txtQtdeFalta);
            this.Controls.Add(this.lblQtdeHoras);
            this.Controls.Add(this.txtQtdeHoras);
            this.Controls.Add(this.btnInstHorista);
            this.Controls.Add(this.gbxHome);
            this.Controls.Add(this.lblEntradaEmpresa);
            this.Controls.Add(this.lblSalarioHora);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.txtEntradaEmpresa);
            this.Controls.Add(this.txtSalarioHora);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.gbxHome.ResumeLayout(false);
            this.gbxHome.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnInstHorista;
        private System.Windows.Forms.GroupBox gbxHome;
        private System.Windows.Forms.RadioButton rbtnNao;
        private System.Windows.Forms.RadioButton rbtnSim;
        private System.Windows.Forms.Label lblEntradaEmpresa;
        private System.Windows.Forms.Label lblSalarioHora;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.TextBox txtEntradaEmpresa;
        private System.Windows.Forms.TextBox txtSalarioHora;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lblQtdeHoras;
        private System.Windows.Forms.TextBox txtQtdeHoras;
        private System.Windows.Forms.Label lblQtdeFalta;
        private System.Windows.Forms.TextBox txtQtdeFalta;
    }
}