﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculadora_de_IMC
{
    public partial class CalculadoraIMC : Form
    {
        double altura, massa, imc;

        private void Altura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            if (!double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Altura Inválida");
            }
        }

        private void Massa_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            if (!double.TryParse(mskbxMassa.Text, out massa))
            {
                MessageBox.Show("Peso Inválido");
            }
        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtClass.Clear();
            txtGrau.Clear();
            txtIMC.Clear();
            mskbxAltura.Clear();
            mskbxMassa.Clear();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void LblAltura_Click(object sender, EventArgs e)
        {

        }

        private void LblMassa_Click(object sender, EventArgs e)
        {

        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Altura Inválida");
            }
            if (!double.TryParse(mskbxMassa.Text, out massa))
            {
                MessageBox.Show("Peso Inválido");
            }
            imc = Math.Round((massa / Math.Pow(altura, 2)), 1);
            txtIMC.Text = imc.ToString();
            if(imc < 18.5)
            {
                txtClass.Text = "Magreza";
                txtGrau.Text = "0";
            }
            else if (imc < 24.9)
            {
                txtClass.Text = "Normal";
                txtGrau.Text = "0";
            }
            else if (imc < 29.9)
            {
                txtClass.Text = "Sobrepeso";
                txtGrau.Text = "1";
            }
            else if (imc < 39.9)
            {
                txtClass.Text = "Obesidade";
                txtGrau.Text = "2";
            }
            else if (imc > 40)
            {
                txtClass.Text = "Obesidade Grave";
                txtGrau.Text = "3";
            }

        }

        public CalculadoraIMC()
        {
            InitializeComponent();
        }

    }
}
